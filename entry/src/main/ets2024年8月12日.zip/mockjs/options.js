const options = [
    {
        mytxt:"发布文章",
        icon:$r("app.media.PublishRound")
    },
    {
        mytxt:"完成任务",
        icon:$r("app.media.CheckmarkDone")
    },
    {
        mytxt:"绑定银行卡",
        icon:$r("app.media.ContactCardLink16Regular")
    },
    {
        mytxt:"在线客服",
        icon:$r("app.media.UserServiceDesk")
    }
]
export default options