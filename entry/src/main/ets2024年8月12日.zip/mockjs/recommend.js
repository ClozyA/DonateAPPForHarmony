const recommend = [
    {
        "icon": $r("app.media.money"),
        "mytitle": "XXXXXXXXXXXXX捐赠仪式"
    },
    {
        "icon": $r("app.media.money2"),
        "mytitle": "XXXXXXXXXXXXX捐赠仪式"
    },
    {
        "icon": $r("app.media.money3"),
        "mytitle": "XXXXXXXXXXXXX捐赠仪式"
    },
    {
        "icon": $r("app.media.money4"),
        "mytitle": "XXXXXXXXXXXXX捐赠仪式"
    },
    {
        "icon": $r("app.media.money5"),
        "mytitle": "扶老助残"
    },
    {
        "icon": $r("app.media.money6"),
        "mytitle": "爱心公益"
    }
]

export default recommend