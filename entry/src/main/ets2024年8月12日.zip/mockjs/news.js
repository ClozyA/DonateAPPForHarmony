const news=[
    {
        "icon":$r("app.media.news2"),
        "mytitle":"最新权威资讯",
        "mysubtitle":"前方信息汇总"
    },
    {
        "icon":$r("app.media.news5"),
        "mytitle":"为奥运加油",
        "mysubtitle":"奥运金牌榜"
    },
    {
        "icon":$r("app.media.news3"),
        "mytitle":"火灾救援科普",
        "mysubtitle":"广东洪水救援"
    },
    {
        "icon":$r("app.media.news4"),
        "mytitle":"关注现场动态",
        "mysubtitle":"为坚强者助力"
    }
]
export default news;