const category = [
    {
        "icon": $r("app.media.money"),
        "mytxt": "慈善捐助"
    },
    {
        "icon": $r("app.media.money2"),
        "mytxt": "爱佑新生"
    },
    {
        "icon": $r("app.media.money3"),
        "mytxt": "公益捐助"
    },
    {
        "icon": $r("app.media.money4"),
        "mytxt": "助学圆梦"
    },
    {
        "icon": $r("app.media.money5"),
        "mytxt": "扶老助残"
    },
    {
        "icon": $r("app.media.money6"),
        "mytxt": "慈善军营"
    },
    {
        "icon": $r("app.media.money7"),
        "mytxt": "免费捐助"
    },
    {
        "icon": $r("app.media.money8"),
        "mytxt": "突发事件"
    }
]

export default category;