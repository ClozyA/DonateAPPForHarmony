const juan_data = [
    {
        icon:$r("app.media.AddLinkOutlined"),
        mytxt:"修改密码"
    },
    {
        icon:$r("app.media.AddLinkOutlined"),
        mytxt:"查看捐赠"
    },
    {
        icon:$r("app.media.AddLinkOutlined"),
        mytxt:"发布捐赠"
    },
    {
        icon:$r("app.media.AddLinkOutlined"),
        mytxt:"我帮助过"
    },
    {
        icon:$r("app.media.AddLinkOutlined"),
        mytxt:"我的订单"
    },
    {
        icon:$r("app.media.AddLinkOutlined"),
        mytxt:"我的众筹"
    }
]
export default juan_data